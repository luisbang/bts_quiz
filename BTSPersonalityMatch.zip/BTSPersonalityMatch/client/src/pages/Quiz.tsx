import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ArrowRight, Loader2 } from "lucide-react";
import { type QuizQuestion, type QuizOption } from "@shared/schema";
import { calculateQuizResult, generateSessionId } from "@/lib/quiz-utils";

export default function Quiz() {
  const [, setLocation] = useLocation();
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<string[]>([]);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [sessionId] = useState(() => generateSessionId());

  const { data: questions, isLoading, error } = useQuery<QuizQuestion[]>({
    queryKey: ['/api/quiz/questions'],
  });

  useEffect(() => {
    setSelectedAnswer(null);
  }, [currentQuestionIndex]);

  if (isLoading) {
    return (
      <div className="min-h-screen gradient-bg flex items-center justify-center p-4">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-white mx-auto mb-4" />
          <p className="text-white text-lg">Loading quiz questions...</p>
        </div>
      </div>
    );
  }

  if (error || !questions) {
    return (
      <div className="min-h-screen gradient-bg flex items-center justify-center p-4">
        <Card className="p-6 text-center">
          <p className="text-red-600 mb-4">Failed to load quiz questions</p>
          <Button onClick={() => setLocation('/')}>Go Home</Button>
        </Card>
      </div>
    );
  }

  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;

  const handleOptionSelect = (memberKey: string) => {
    setSelectedAnswer(memberKey);
  };

  const handleNextQuestion = async () => {
    if (!selectedAnswer) return;

    const newAnswers = [...answers, selectedAnswer];
    setAnswers(newAnswers);

    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      // Quiz completed, calculate result
      const resultMember = calculateQuizResult(newAnswers);
      
      // Save result to backend
      try {
        await fetch('/api/quiz/results', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            sessionId,
            memberKey: resultMember,
            answers: newAnswers,
            completedAt: new Date().toISOString(),
          }),
        });
      } catch (error) {
        console.error('Failed to save quiz result:', error);
      }
      
      // Navigate to results
      setLocation(`/results/${resultMember}`);
    }
  };

  return (
    <div className="min-h-screen gradient-bg p-4">
      {/* Progress Bar */}
      <div className="max-w-4xl mx-auto mb-8">
        <div className="bg-white/20 rounded-full p-1 mb-4">
          <Progress 
            value={progress} 
            className="h-2 bg-gradient-to-r from-yellow-300 to-pink-300"
          />
        </div>
        <div className="flex justify-between text-white text-sm font-medium">
          <span>Question {currentQuestionIndex + 1} of {questions.length}</span>
          <span>{Math.round(progress)}%</span>
        </div>
      </div>

      {/* Quiz Container */}
      <div className="max-w-4xl mx-auto">
        <Card className="question-card p-8 mb-8 shadow-2xl hover:shadow-3xl transition-all duration-300">
          <CardContent className="p-0">
            <div className="animate-fade-in">
              <h3 className="text-3xl font-bold text-gray-800 mb-8 text-center font-poppins">
                {currentQuestion.question}
              </h3>
              <div className="grid gap-4 md:grid-cols-2">
                {(currentQuestion.options as QuizOption[]).map((option, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    className={`option-btn p-6 h-auto text-left justify-start hover:border-purple-500 hover:bg-purple-50 transition-all duration-300 ${
                      selectedAnswer === option.member 
                        ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white border-purple-500 scale-105' 
                        : 'border-gray-200 text-gray-700'
                    }`}
                    onClick={() => handleOptionSelect(option.member)}
                  >
                    <div className="flex items-center w-full">
                      <div className="w-8 h-8 rounded-full border-2 border-current flex items-center justify-center mr-4 text-sm font-bold flex-shrink-0">
                        {String.fromCharCode(65 + index)}
                      </div>
                      <span className="flex-1">{option.text}</span>
                    </div>
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="text-center">
          <Button
            onClick={handleNextQuestion}
            disabled={!selectedAnswer}
            size="lg"
            className={`font-semibold px-8 py-3 text-lg shadow-lg hover:scale-105 transition-all duration-300 rounded-full ${
              selectedAnswer 
                ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white' 
                : 'opacity-50 cursor-not-allowed'
            }`}
          >
            {currentQuestionIndex < questions.length - 1 ? 'Next Question' : 'Get Results'}
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
