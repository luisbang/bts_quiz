import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, Share, Loader2 } from "lucide-react";
import { type BtsMemberProfile } from "@shared/schema";

interface ResultsProps {
  params: {
    memberKey: string;
  };
}

export default function Results({ params }: ResultsProps) {
  const [, setLocation] = useLocation();
  const [isVisible, setIsVisible] = useState(false);
  const { memberKey } = params;

  const { data: member, isLoading, error } = useQuery<BtsMemberProfile>({
    queryKey: [`/api/members/${memberKey}`],
  });

  useEffect(() => {
    if (member) {
      // Show loading page briefly for dramatic effect
      setTimeout(() => {
        setIsVisible(true);
      }, 1000);
    }
  }, [member]);

  if (isLoading || !isVisible) {
    return (
      <div className="min-h-screen gradient-bg flex items-center justify-center p-4">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-t-4 border-white border-opacity-75 mx-auto mb-8"></div>
          <h2 className="text-3xl font-bold text-white mb-4 font-poppins">
            Calculating Your Result... ✨
          </h2>
          <p className="text-white/80 text-lg">
            Finding your BTS personality match!
          </p>
        </div>
      </div>
    );
  }

  if (error || !member) {
    return (
      <div className="min-h-screen gradient-bg flex items-center justify-center p-4">
        <Card className="p-6 text-center">
          <p className="text-red-600 mb-4">Failed to load result</p>
          <Button onClick={() => setLocation('/')}>Go Home</Button>
        </Card>
      </div>
    );
  }

  const handleRestart = () => {
    setLocation('/');
  };

  const handleShare = async () => {
    const shareText = `I just took the BTS personality quiz and got ${member.name}! 💜 Find out which BTS member you are most like!`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Which BTS Member Are You?',
          text: shareText,
          url: window.location.origin,
        });
      } catch (error) {
        console.log('Error sharing:', error);
      }
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(shareText + ' ' + window.location.origin);
      alert('Result shared to clipboard! 💜');
    }
  };

  return (
    <div className="min-h-screen gradient-bg flex items-center justify-center p-4">
      <div className="max-w-2xl mx-auto text-center">
        <div className="animate-celebrate">
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-4 font-poppins">
            You Are Most Like... 🎉
          </h2>
        </div>

        <Card className="p-8 shadow-2xl mb-8 animate-bounce-in">
          <CardContent className="p-0">
            <div className="text-center">
              <div className="relative inline-block mb-6">
                <img
                  src={member.imageUrl}
                  alt={member.name}
                  className="w-32 h-32 rounded-full mx-auto object-cover shadow-lg border-4 border-white"
                />
                <div className={`absolute -top-2 -right-2 bg-gradient-to-r ${member.color} text-white text-2xl p-2 rounded-full`}>
                  💜
                </div>
              </div>
              
              <h3 className="text-4xl font-bold text-gray-800 mb-4 font-poppins">
                {member.name}
              </h3>
              
              <div className="flex flex-wrap justify-center gap-2 mb-6">
                {(member.traits as string[]).map((trait, index) => (
                  <Badge
                    key={index}
                    className={`bg-gradient-to-r ${member.color} text-white px-3 py-1 text-sm font-medium`}
                  >
                    {trait}
                  </Badge>
                ))}
              </div>
              
              <p className="text-gray-600 text-lg leading-relaxed">
                {member.description}
              </p>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-4">
          <Button
            onClick={handleRestart}
            size="lg"
            className="bg-gradient-to-r from-purple-500 to-pink-500 text-white font-semibold px-8 py-3 text-lg shadow-lg hover:scale-105 transition-all duration-300 mr-4 rounded-full"
          >
            <RefreshCw className="mr-2 h-5 w-5" />
            Take Quiz Again
          </Button>
          
          <Button
            onClick={handleShare}
            variant="outline"
            size="lg"
            className="bg-white text-purple-600 font-semibold px-8 py-3 text-lg shadow-lg hover:scale-105 transition-all duration-300 border-2 border-white/20 rounded-full"
          >
            <Share className="mr-2 h-5 w-5" />
            Share Result
          </Button>
        </div>
      </div>
    </div>
  );
}
