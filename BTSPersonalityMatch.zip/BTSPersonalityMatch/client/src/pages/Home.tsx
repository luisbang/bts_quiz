import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Play, Star, Heart, Music, Sun } from "lucide-react";

export default function Home() {
  const [, setLocation] = useLocation();
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
    
    // Create floating hearts effect
    const heartsContainer = document.getElementById('floating-hearts-home');
    if (!heartsContainer) return;
    
    const interval = setInterval(() => {
      const heart = document.createElement('div');
      heart.className = 'floating-heart';
      heart.innerHTML = '💜';
      heart.style.position = 'absolute';
      heart.style.left = Math.random() * 100 + '%';
      heart.style.fontSize = '20px';
      heart.style.pointerEvents = 'none';
      heart.style.animation = `float-up ${Math.random() * 3 + 6}s ease-in-out forwards`;
      heart.style.color = '#EC4899';
      
      heartsContainer.appendChild(heart);
      
      setTimeout(() => {
        if (heart.parentNode) {
          heart.parentNode.removeChild(heart);
        }
      }, 9000);
    }, 3000);
    
    return () => clearInterval(interval);
  }, []);

  const startQuiz = () => {
    setLocation('/quiz');
  };

  return (
    <div className="min-h-screen gradient-bg flex items-center justify-center p-4 relative overflow-hidden">
      {/* Floating Hearts Container */}
      <div id="floating-hearts-home" className="absolute inset-0 pointer-events-none" />
      
      <div className="text-center max-w-2xl mx-auto relative z-10">
        <div className={`transition-all duration-800 ${isVisible ? 'animate-bounce-in opacity-100' : 'opacity-0 scale-50'}`}>
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-4 drop-shadow-lg font-poppins">
            Which BTS Member
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-pink-300">
              Are You? 💜
            </span>
          </h1>
          <p className="text-xl md:text-2xl text-white/90 mb-8 font-light">
            Discover your BTS personality match through our fun quiz!
          </p>
        </div>
        
        <div className={`transition-all duration-600 delay-500 ${isVisible ? 'animate-fade-in opacity-100' : 'opacity-0 translate-y-5'}`}>
          <Button
            onClick={startQuiz}
            size="lg"
            className="bg-white text-purple-600 hover:bg-purple-50 font-semibold px-8 py-4 text-xl shadow-2xl hover:scale-105 transition-all duration-300 border-4 border-white/20 rounded-full"
          >
            <Play className="mr-3 h-5 w-5" />
            Start Quiz
          </Button>
        </div>
        
        <div className={`mt-12 transition-all duration-500 delay-700 ${isVisible ? 'animate-slide-up opacity-100' : 'opacity-0 translate-y-8'}`}>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-md mx-auto">
            <Card className="glass-effect p-3 text-center border-white/20 bg-white/10 backdrop-blur-10">
              <Star className="text-yellow-300 h-8 w-8 mx-auto mb-2" />
              <p className="text-white text-sm font-medium">RM</p>
            </Card>
            <Card className="glass-effect p-3 text-center border-white/20 bg-white/10 backdrop-blur-10">
              <Heart className="text-pink-300 h-8 w-8 mx-auto mb-2" />
              <p className="text-white text-sm font-medium">Jin</p>
            </Card>
            <Card className="glass-effect p-3 text-center border-white/20 bg-white/10 backdrop-blur-10">
              <Music className="text-blue-300 h-8 w-8 mx-auto mb-2" />
              <p className="text-white text-sm font-medium">Suga</p>
            </Card>
            <Card className="glass-effect p-3 text-center border-white/20 bg-white/10 backdrop-blur-10">
              <Sun className="text-orange-300 h-8 w-8 mx-auto mb-2" />
              <p className="text-white text-sm font-medium">J-Hope</p>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
