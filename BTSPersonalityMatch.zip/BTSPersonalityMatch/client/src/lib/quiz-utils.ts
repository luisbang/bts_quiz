import { type QuizOption } from "@shared/schema";

export function calculateQuizResult(answers: string[]): string {
  // Count answers for each member
  const memberCounts: Record<string, number> = {};
  
  answers.forEach(answer => {
    memberCounts[answer] = (memberCounts[answer] || 0) + 1;
  });
  
  // Find member with most answers
  let resultMember = Object.keys(memberCounts).reduce((a, b) => 
    memberCounts[a] > memberCounts[b] ? a : b
  );
  
  return resultMember;
}

export function generateSessionId(): string {
  return `quiz_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

export function createFloatingHearts(containerId: string) {
  const heartsContainer = document.getElementById(containerId);
  if (!heartsContainer) return;
  
  const interval = setInterval(() => {
    const heart = document.createElement('div');
    heart.className = 'floating-heart';
    heart.innerHTML = '💜';
    heart.style.position = 'absolute';
    heart.style.left = Math.random() * 100 + '%';    heart.style.fontSize = '20px';
    heart.style.pointerEvents = 'none';
    heart.style.animation = `float-up ${Math.random() * 3 + 6}s ease-in-out forwards`;
    heart.style.animationDelay = Math.random() * 6 + 's';
    
    heartsContainer.appendChild(heart);
    
    // Remove heart after animation
    setTimeout(() => {
      if (heart.parentNode) {
        heart.parentNode.removeChild(heart);
      }
    }, 9000);
  }, 3000);
  
  return () => clearInterval(interval);
}
