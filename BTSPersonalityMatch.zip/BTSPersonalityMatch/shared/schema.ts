import { pgTable, text, serial, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const quizQuestions = pgTable("quiz_questions", {
  id: serial("id").primaryKey(),
  question: text("question").notNull(),
  options: jsonb("options").notNull(), // Array of {text: string, member: string}
  order: integer("order").notNull(),
});

export const btsMemberProfiles = pgTable("bts_member_profiles", {
  id: serial("id").primaryKey(),
  memberKey: text("member_key").notNull().unique(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  traits: jsonb("traits").notNull(), // Array of strings
  color: text("color").notNull(),
  imageUrl: text("image_url").notNull(),
});

export const quizResults = pgTable("quiz_results", {
  id: serial("id").primaryKey(),
  sessionId: text("session_id").notNull(),
  memberKey: text("member_key").notNull(),
  answers: jsonb("answers").notNull(), // Array of member keys
  completedAt: text("completed_at").notNull(),
});

// Zod schemas
export const insertQuizQuestionSchema = createInsertSchema(quizQuestions).omit({
  id: true,
});

export const insertBtsMemberProfileSchema = createInsertSchema(btsMemberProfiles).omit({
  id: true,
});

export const insertQuizResultSchema = createInsertSchema(quizResults).omit({
  id: true,
});

// Types
export type QuizQuestion = typeof quizQuestions.$inferSelect;
export type InsertQuizQuestion = z.infer<typeof insertQuizQuestionSchema>;

export type BtsMemberProfile = typeof btsMemberProfiles.$inferSelect;
export type InsertBtsMemberProfile = z.infer<typeof insertBtsMemberProfileSchema>;

export type QuizResult = typeof quizResults.$inferSelect;
export type InsertQuizResult = z.infer<typeof insertQuizResultSchema>;

// Option type for quiz questions
export type QuizOption = {
  text: string;
  member: string;
};
