import { 
  quizQuestions, 
  btsMemberProfiles, 
  quizResults,
  type QuizQuestion, 
  type BtsMemberProfile, 
  type QuizResult,
  type InsertQuizQuestion,
  type InsertBtsMemberProfile,
  type InsertQuizResult,
  type QuizOption
} from "@shared/schema";

export interface IStorage {
  // Quiz Questions
  getQuizQuestions(): Promise<QuizQuestion[]>;
  
  // BTS Member Profiles
  getBtsMemberProfiles(): Promise<BtsMemberProfile[]>;
  getBtsMemberByKey(memberKey: string): Promise<BtsMemberProfile | undefined>;
  
  // Quiz Results
  saveQuizResult(result: InsertQuizResult): Promise<QuizResult>;
}

export class MemStorage implements IStorage {
  private questions: Map<number, QuizQuestion> = new Map();
  private memberProfiles: Map<string, BtsMemberProfile> = new Map();
  private results: Map<number, QuizResult> = new Map();
  private currentId = 1;
  private currentResultId = 1;

  constructor() {
    this.initializeData();
  }

  private initializeData() {
    // Initialize quiz questions
    const questionsData: Omit<QuizQuestion, 'id'>[] = [
      {
        question: "What's your ideal way to spend a weekend?",
        options: [
          { text: "Reading books or learning something new", member: "RM" },
          { text: "Cooking for friends and family", member: "Jin" },
          { text: "Working on music or creative projects", member: "Suga" },
          { text: "Dancing and spreading positive energy", member: "J-Hope" },
          { text: "Spending quality time with loved ones", member: "Jimin" },
          { text: "Exploring art galleries or photography", member: "V" },
          { text: "Playing games or sports", member: "Jungkook" }
        ],
        order: 1
      },
      {
        question: "How do you handle stress?",
        options: [
          { text: "Think through problems logically", member: "RM" },
          { text: "Make jokes to lighten the mood", member: "Jin" },
          { text: "Find a quiet space to recharge", member: "Suga" },
          { text: "Stay positive and motivate others", member: "J-Hope" },
          { text: "Talk to friends for support", member: "Jimin" },
          { text: "Express feelings through art", member: "V" },
          { text: "Exercise or do physical activities", member: "Jungkook" }
        ],
        order: 2
      },
      {
        question: "What's your biggest strength?",
        options: [
          { text: "Leadership and wisdom", member: "RM" },
          { text: "Caring for others", member: "Jin" },
          { text: "Authenticity and honesty", member: "Suga" },
          { text: "Optimism and energy", member: "J-Hope" },
          { text: "Empathy and kindness", member: "Jimin" },
          { text: "Creativity and uniqueness", member: "V" },
          { text: "Versatility and determination", member: "Jungkook" }
        ],
        order: 3
      },
      {
        question: "What type of music speaks to you most?",
        options: [
          { text: "Deep, meaningful lyrics", member: "RM" },
          { text: "Feel-good pop songs", member: "Jin" },
          { text: "Raw, emotional tracks", member: "Suga" },
          { text: "Upbeat, danceable music", member: "J-Hope" },
          { text: "Romantic, heartfelt ballads", member: "Jimin" },
          { text: "Unique, experimental sounds", member: "V" },
          { text: "Versatile genres, anything good", member: "Jungkook" }
        ],
        order: 4
      },
      {
        question: "How do you prefer to express yourself?",
        options: [
          { text: "Through thoughtful words", member: "RM" },
          { text: "Through humor and warmth", member: "Jin" },
          { text: "Through honest emotions", member: "Suga" },
          { text: "Through movement and energy", member: "J-Hope" },
          { text: "Through caring actions", member: "Jimin" },
          { text: "Through creative arts", member: "V" },
          { text: "Through various talents", member: "Jungkook" }
        ],
        order: 5
      },
      {
        question: "What's your approach to friendships?",
        options: [
          { text: "Deep, meaningful connections", member: "RM" },
          { text: "Being the caring older sibling", member: "Jin" },
          { text: "Loyal but need personal space", member: "Suga" },
          { text: "Bringing joy and laughter", member: "J-Hope" },
          { text: "Always there for emotional support", member: "Jimin" },
          { text: "Unique, unpredictable friendship", member: "V" },
          { text: "Fun, competitive and loyal", member: "Jungkook" }
        ],
        order: 6
      },
      {
        question: "What motivates you most?",
        options: [
          { text: "Making a positive impact", member: "RM" },
          { text: "Making others happy", member: "Jin" },
          { text: "Being true to yourself", member: "Suga" },
          { text: "Spreading positivity", member: "J-Hope" },
          { text: "Connecting with others", member: "Jimin" },
          { text: "Creative self-expression", member: "V" },
          { text: "Constant improvement", member: "Jungkook" }
        ],
        order: 7
      },
      {
        question: "How do you handle challenges?",
        options: [
          { text: "Analyze and strategize", member: "RM" },
          { text: "Stay calm and supportive", member: "Jin" },
          { text: "Face them head-on honestly", member: "Suga" },
          { text: "Maintain hope and positivity", member: "J-Hope" },
          { text: "Work hard with dedication", member: "Jimin" },
          { text: "Find creative solutions", member: "V" },
          { text: "Practice until perfect", member: "Jungkook" }
        ],
        order: 8
      },
      {
        question: "What's your ideal role in a group?",
        options: [
          { text: "The thoughtful leader", member: "RM" },
          { text: "The caring older member", member: "Jin" },
          { text: "The honest voice of reason", member: "Suga" },
          { text: "The mood maker", member: "J-Hope" },
          { text: "The emotional support", member: "Jimin" },
          { text: "The creative wildcard", member: "V" },
          { text: "The versatile talent", member: "Jungkook" }
        ],
        order: 9
      },
      {
        question: "What's most important to you in life?",
        options: [
          { text: "Growth and learning", member: "RM" },
          { text: "Family and relationships", member: "Jin" },
          { text: "Authenticity and truth", member: "Suga" },
          { text: "Happiness and positivity", member: "J-Hope" },
          { text: "Love and connection", member: "Jimin" },
          { text: "Art and beauty", member: "V" },
          { text: "Excellence and achievement", member: "Jungkook" }
        ],
        order: 10
      }
    ];

    questionsData.forEach((questionData, index) => {
      const question: QuizQuestion = {
        id: this.currentId++,
        ...questionData
      };
      this.questions.set(question.id, question);
    });

    // Initialize BTS member profiles
    const memberProfilesData: Omit<BtsMemberProfile, 'id'>[] = [
      {
        memberKey: "RM",
        name: "RM (Namjoon)",
        description: "You're a natural leader with deep thoughts and big dreams! Like RM, you have wisdom beyond your years and the ability to inspire others with your words. You're philosophical, articulate, and always seeking to grow and learn.",
        traits: ["Thoughtful Leader", "Philosophical", "Articulate", "Growth-minded"],
        color: "from-purple-500 to-blue-500",
        imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&h=500"
      },
      {
        memberKey: "Jin",
        name: "Jin (Seokjin)",
        description: "You're the caring heart of any group! Like Jin, you have a warm personality and love taking care of others. You bring comfort, humor, and stability to those around you. You're the reliable friend everyone needs.",
        traits: ["Caring", "Reliable", "Humorous", "Nurturing"],
        color: "from-pink-500 to-red-500",
        imageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&h=500"
      },
      {
        memberKey: "Suga",
        name: "Suga (Yoongi)",
        description: "You're authentic and deeply emotional! Like Suga, you value honesty and aren't afraid to show your true feelings. You're creative, passionate, and have a unique way of seeing the world. Your authenticity is your strength.",
        traits: ["Authentic", "Creative", "Honest", "Passionate"],
        color: "from-gray-600 to-black",
        imageUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&h=500"
      },
      {
        memberKey: "J-Hope",
        name: "J-Hope (Hoseok)",
        description: "You're pure sunshine! Like J-Hope, you radiate positivity and bring joy wherever you go. You're the mood maker, the one who lifts everyone's spirits and keeps hope alive even in difficult times. Your energy is infectious!",
        traits: ["Positive", "Energetic", "Mood Maker", "Hopeful"],
        color: "from-yellow-400 to-orange-500",
        imageUrl: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&h=500"
      },
      {
        memberKey: "Jimin",
        name: "Jimin",
        description: "You have a beautiful, caring soul! Like Jimin, you're incredibly empathetic and always put others first. You work hard to perfect your craft and are deeply loved for your kind heart and dedication to those you care about.",
        traits: ["Empathetic", "Caring", "Dedicated", "Perfectionist"],
        color: "from-pink-400 to-purple-500",
        imageUrl: "https://images.unsplash.com/photo-1507591064344-4c6ce005b128?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&h=500"
      },
      {
        memberKey: "V",
        name: "V (Taehyung)",
        description: "You're beautifully unique! Like V, you have an artistic soul and see the world through a creative lens. You're unpredictable in the best way, bringing fresh perspectives and innovative ideas to everything you do.",
        traits: ["Creative", "Unique", "Artistic", "Innovative"],
        color: "from-green-400 to-blue-500",
        imageUrl: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&h=500"
      },
      {
        memberKey: "Jungkook",
        name: "Jungkook",
        description: "You're incredibly talented and versatile! Like Jungkook, you excel at everything you try and are always pushing yourself to be better. You're competitive, driven, and have the golden touch that makes everything you do special.",
        traits: ["Versatile", "Talented", "Competitive", "Driven"],
        color: "from-purple-500 to-pink-500",
        imageUrl: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&h=500"
      }
    ];

    memberProfilesData.forEach((profileData, index) => {
      const profile: BtsMemberProfile = {
        id: index + 1,
        ...profileData
      };
      this.memberProfiles.set(profile.memberKey, profile);
    });
  }

  async getQuizQuestions(): Promise<QuizQuestion[]> {
    return Array.from(this.questions.values()).sort((a, b) => a.order - b.order);
  }

  async getBtsMemberProfiles(): Promise<BtsMemberProfile[]> {
    return Array.from(this.memberProfiles.values());
  }

  async getBtsMemberByKey(memberKey: string): Promise<BtsMemberProfile | undefined> {
    return this.memberProfiles.get(memberKey);
  }

  async saveQuizResult(result: InsertQuizResult): Promise<QuizResult> {
    const quizResult: QuizResult = {
      id: this.currentResultId++,
      ...result
    };
    this.results.set(quizResult.id, quizResult);
    return quizResult;
  }
}

export const storage = new MemStorage();
