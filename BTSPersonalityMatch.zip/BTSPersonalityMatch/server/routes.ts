import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertQuizResultSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all quiz questions
  app.get("/api/quiz/questions", async (_req, res) => {
    try {
      const questions = await storage.getQuizQuestions();
      res.json(questions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch quiz questions" });
    }
  });

  // Get all BTS member profiles
  app.get("/api/members", async (_req, res) => {
    try {
      const members = await storage.getBtsMemberProfiles();
      res.json(members);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch member profiles" });
    }
  });

  // Get a specific BTS member by key
  app.get("/api/members/:memberKey", async (req, res) => {
    try {
      const { memberKey } = req.params;
      const member = await storage.getBtsMemberByKey(memberKey);
      
      if (!member) {
        return res.status(404).json({ message: "Member not found" });
      }
      
      res.json(member);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch member profile" });
    }
  });

  // Save quiz result
  app.post("/api/quiz/results", async (req, res) => {
    try {
      const validatedData = insertQuizResultSchema.parse(req.body);
      const result = await storage.saveQuizResult(validatedData);
      res.json(result);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid quiz result data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to save quiz result" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
